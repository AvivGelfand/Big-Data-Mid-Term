import sys
import re
import os
from collections import Counter

def top_k_words(file_name, k):
    # Read file content
    with open(file_name, 'r') as file:
        content = file.read().lower()  # Convert to lower case for uniformity

    # Tokenize and count words
    words = re.findall(r'\w+', content)  # This regex finds words in the content
    word_count = Counter(words)

    # Get top-k words
    top_k = word_count.most_common(k)

    # Create output file name
    output_file_name = os.path.splitext(file_name)[0] + "_topk.txt"

    # Write the top-k words to the output file
    with open(output_file_name, 'w') as file:
        for word, count in top_k:
            file.write(f'{word}: {count}\n')

    print(f'Top-{k} words written to {output_file_name} are (word , #appearances):')
    for word, count in top_k:
        print(word + " , " + str(count))
    # Also print them:

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 count_topk.py <filename> <k>")
        sys.exit(1)

    input_file = sys.argv[1]
    k = int(sys.argv[2])

    top_k_words(input_file, k)

# Example usage
# top_k_words('cases_differences.txt', 10)
